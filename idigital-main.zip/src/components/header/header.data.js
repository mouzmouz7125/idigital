export default [
  {
    path: "",
    label: "ACCUEIL",
    isPageLink: true,
  },
  {
    path: "promo",
    label: "PROMOS",
    isPageLink: false,
  },
  {
    path: "prix-creation-site-internet",
    label: "NOS TARIFS",
    isPageLink: true,
  },
  {
    path: "contact",
    label: "CONTACT",
    isPageLink: true,
  },
];
